# Franceschetta58 Android V10.1

Wrapper Android della V10.1 di Franceschetta58.

- applicationId: `it.franceschetta58.kitchen`
- minSdk: 26
- targetSdk: 35
- UI inclusa in `app/src/main/assets/index.html`
- dettatura vocale tramite Android `RecognizerIntent`
- icona gialla F58
- workflow GitHub Actions incluso per generare l'APK
